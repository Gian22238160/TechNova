Avances del Proyecto Final de Taller de Programación Web
Integrantes:
- Abdul Quintanilla Acosta
- Braulio Jesus Javier Buendia
- Estefany Lesly Trujillo Yzquierdo
- Giancarlo Joel Terrones Peña
- Miguel Angel Coveñas Chiroque
